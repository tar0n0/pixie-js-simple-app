import * as PIXI from "pixi.js";

const app = new PIXI.Application({ resizeTo: window });
document.body.appendChild(app.view);

const M = 7;
const N = 8;
const X = 5;
const Y = 3;

const ICON_SIZE = 50;
const BORDER_SIZE = 2;
const colors = ["yellow", "green", "orange", "red", "blue"];
let field = [];
let clusterHighlights = [];
let blinkingInterval = null;

function createField() {
  for (let i = 0; i < M; i++) {
    field[i] = [];
    for (let j = 0; j < N; j++) {
      const color = colors[Math.floor(Math.random() * colors.length)];
      const icon = new PIXI.Graphics();
      icon.beginFill(PIXI.utils.string2hex(color));
      icon.lineStyle(BORDER_SIZE, 0x000000);
      icon.drawRect(0, 0, ICON_SIZE, ICON_SIZE);
      icon.endFill();
      icon.x = i * ICON_SIZE;
      icon.y = j * ICON_SIZE;
      app.stage.addChild(icon);
      field[i][j] = { color, icon };
    }
  }
}

function findClusters() {
  const clusters = [];
  const visited = new Set();

  function dfs(x, y, color, cluster) {
    if (
      x < 0 ||
      y < 0 ||
      x >= M ||
      y >= N ||
      visited.has(`${x},${y}`) ||
      field[x][y].color !== color
    ) {
      return;
    }
    visited.add(`${x},${y}`);
    cluster.push({ x, y });

    dfs(x + 1, y, color, cluster);
    dfs(x - 1, y, color, cluster);
    dfs(x, y + 1, color, cluster);
    dfs(x, y - 1, color, cluster);
  }

  for (let i = 0; i < M; i++) {
    for (let j = 0; j < N; j++) {
      const { color } = field[i][j];
      if (!visited.has(`${i},${j}`)) {
        const cluster = [];
        dfs(i, j, color, cluster);
        if (cluster.length >= Y) {
          clusters.push(cluster);
        }
      }
    }
  }

  return clusters;
}

function highlightClusters(clusters) {
  for (const cluster of clusters) {
    for (const { x, y } of cluster) {
      const highlight = new PIXI.Text("!", { fill: "black" });
      highlight.anchor.set(0.5);
      highlight.position.set((x + 0.5) * ICON_SIZE, (y + 0.5) * ICON_SIZE);
      app.stage.addChild(highlight);
      clusterHighlights.push(highlight);
    }
  }

  if (blinkingInterval) {
    clearInterval(blinkingInterval);
  }

  let isHighlighted = true;
  blinkingInterval = setInterval(() => {
    for (const highlight of clusterHighlights) {
      highlight.alpha = isHighlighted ? 1 : 0;
    }
    isHighlighted = !isHighlighted;
  }, 500);
}

function clearStage() {
  app.stage.removeChildren();
  field = [];
  clusterHighlights = [];
}

function startGame() {
  clearStage();
  createField();
  const clusters = findClusters();
  highlightClusters(clusters);

  const startButton = new PIXI.Text("Start", { fill: "white" });
  startButton.position.set(app.screen.width / 1.2, 10);
  startButton.interactive = true;
  startButton.buttonMode = true;
  startButton.on("pointerdown", startGame);
  app.stage.addChild(startButton);
}

startGame();
